from flask import *

from profiles import get_profile_details, get_profiles
site = Flask("SparkRentalService")
@site.route("/")
def main_page():
    return render_template("main.html",profiles = get_profiles()["profiles"])
@site.route("/user")
def not_found():
    return "User not Found"
@site.route("/user/<username>")
def user_page(username):
    user = get_profile_details(username)
    return render_template("user.html",user=user)
site.run()