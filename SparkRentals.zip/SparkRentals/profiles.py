import json
def get_profiles():
    return json.load(open("profiles.json"))
def get_profile_details(username):
    profiles = json.load(open("profiles.json"))["profiles"]
    for profile in profiles:
        if profile["username"] == username:
            return profile